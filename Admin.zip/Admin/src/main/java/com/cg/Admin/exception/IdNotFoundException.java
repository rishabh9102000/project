package com.cg.Admin.exception;

public class IdNotFoundException extends Exception{
	public IdNotFoundException(String message) {
		super(message);
	}

}
